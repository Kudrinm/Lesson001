a = 2
b = 4
c = 3
f = (a*b) + (a*c)
print (( f**3)/2)