print("5")
number = 5
string_number = str(number)
length = len(string_number)
print(length)