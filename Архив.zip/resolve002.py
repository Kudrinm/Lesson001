first = 5
second = 3
summa = first + second
diff = first - second
print ( summa )
print ( diff )