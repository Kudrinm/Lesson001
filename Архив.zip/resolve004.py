first_string = monday
second_string = tuesday
print ('first_string , second_string')