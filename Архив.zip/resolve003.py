first = 2
second = 3
third = 4
mean = ( first + second + third ) / 3
print ( mean )